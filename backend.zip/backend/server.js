// изменения 07.06
import dotenv from 'dotenv'

import express from 'express'
import mysql from "mysql2"
import cors from 'cors'

import bodyParser from 'body-parser'
import cookieParser from 'cookie-parser'
import session from 'express-session'

import bcrypt from 'bcrypt'
const saltRounds = 10

dotenv.config()

const app = express()

// configure env file in production
if (process.env.NODE_ENV === undefined) {
	dotenv.config({ path: '../.env' })
}

app.use(express.json())
app.use(cors({
	origin: ['http://localhost:3001'],
	methods: ['GET', 'POST'],
	credentials: true
}))
app.use(cookieParser())
app.use(bodyParser.urlencoded({ extended: true }))

app.use(
	session({
		key: "userId", // ИЗМЕНИТЬ ЗНАЧЕНИЕ НА ИМЯ ПОЛЬЗОВАТЕЛЯ
		secret: 'subscribe',
		resave: false,
		saveUninitialized: false,
		cookie: {
			expires: 60 * 60 * 24
		},
	})
)

const db = mysql.createConnection({
	host: "127.0.0.1",
	port: 3306,
	user: "root",
	database: "auth_smart",
	password: "",
	// credentials: true,
});

app.post('/register', (req, res) => {
	const firstName = req.body.firstName
	const email = req.body.email
	const password = req.body.password

	bcrypt.hash(password, saltRounds, (err, hash) => {
		if (err) {
			console.log(err)
		}

		db.query(
			'INSERT INTO users(username, password, email) VALUES(?, ?, ?)',
			[firstName, hash, email],
			(err, result) => {
				if (err) {
					console.log("Ошибка из БД", err)
				}
				else {
					console.log("Регистрация прошла успешно", result)
				}
			}
		)
	})
})

app.get('/login', (req, res) => {
	if (req.session.user) {
		res.send({ loggedIn: true, user: req.session.user })
	}
	else {
		res.send({ loggedIn: false })
	}
})

app.post('/login', (req, res) => {
	const email = req.body.email
	const password = req.body.password

	db.query(
		'SELECT * FROM users WHERE email = ?',
		email,
		(err, result) => {
			if (err) {
				res.send({ err: err })
			}

			if (result.length > 0) {
				bcrypt.compare(password, result[0].password, (error, responses) => {
					if (responses) {
						req.session.user = result;
						console.log(req.session.user);
						res.send(result);
					}
					else {
						res.send({ message: 'Нет пользователя с таким email или паролем!' })
					}
				})
			}
			else {
				res.send({ message: 'Пользователя не существует!' })
			}
		}
	)
})

// добавление данных с сайта (страница room)
app.post('/room', (req, res) => {
	const vlaga = req.body.vlaga
	const holod = req.body.holod
	const teplo = req.body.teplo
	const temp = req.body.temp

	db.query(
		'INSERT INTO temp_values(vlaga, holod, teplo, temp) VALUES(?, ?, ?, ?)',
		[vlaga, holod, teplo, temp],
		(err, result) => {
			if (err) {
				console.log("Ошибка добавления в БД", err)
			}
			else {
				console.log("Запись с датчиков прошла успешно", result)
			}
		}
	)
})

// удаление последних 5-ти строк данных с сайта (страница room)
// app.post('/room1', (req, res) => {
// 	const vlaga = req.body.vlaga
// 	const holod = req.body.holod
// 	const teplo = req.body.teplo
// 	const temp = req.body.temp

// 	db.query(
// 		// 'DELETE FROM temp_values WHERE (vlaga, holod, teplo, temp) IN ( SELECT * FROM temp_values ORDER BY (vlaga, holod, teplo, temp) DESC LIMIT 5)',
// 		'DELETE FROM temp_values WHERE (vlaga) < ( SELECT MAX(vlaga) - 5 )',
// 		[vlaga, holod, teplo, temp],
// 		(err, result) => {
// 			if (err) {
// 				console.log("Ошибка удаления в БД", err)
// 			}
// 			else {
// 				console.log("Удаление с датчиков прошло успешно", result)
// 			}
// 		}
// 	)
// })

app.listen(5000, () => {
	console.log("Running server", 5000)
})